#!/usr/bin/env python3
"""Exact-integer interval verifier for n=4 subset inequality.
No floating point is used in certifications.
Uses fixed point bracketing of logarithms with explicitly bounded Taylor tails.
"""
import math, json, hashlib, time, os
from functools import lru_cache
from check_no49 import classes, subcube, dist_counts, boundary

BITS=128
S=1<<BITS
TERMS=60

def ceildiv(a,b):return -((-a)//b)

def atanh2(z_n,z_d):
    """Bounds log((1+z)/(1-z)) at fixed scale S, 0<=z<=1/3.
    For 60 Taylor terms tail * S < 1, since 2*S*(1/3)**121 /(121*(1-1/9)) < 1.
    """
    assert 0<=3*z_n<=z_d
    assert 9*S < 4*(2*TERMS+1)*3**(2*TERMS+1)  # strict omitted-tail bound: < 1 scaled unit
    a=(z_n*S)//z_d
    b=ceildiv(z_n*S,z_d)
    al=ah=a; bl=bh=b
    lo=hi=0
    for k in range(TERMS):
        divisor=2*k+1
        lo+=al//divisor
        hi+=ceildiv(bl,divisor)
        if k+1<TERMS:
            al=al*a*a//(S*S)
            bl=ceildiv(bl*b*b,S*S)
    return 2*lo,2*hi+1

LOG2L,LOG2H=atanh2(1,3)

@lru_cache(maxsize=100000)
def log_rat(n,d=1):
    assert n>0 and d>0
    if n==d:return (0,0)
    e=n.bit_length()-d.bit_length()
    if e>=0:
        if n<(d<<e):e-=1
    else:
        if (n<<(-e))<d:e-=1
    if e>=0:norm_n,norm_d=n,d<<e
    else:norm_n,norm_d=n<<(-e),d
    assert norm_d<=norm_n<2*norm_d
    zl,zh=atanh2(norm_n-norm_d,norm_n+norm_d)
    if e>=0:return e*LOG2L+zl,e*LOG2H+zh
    return e*LOG2H+zl,e*LOG2L+zh

@lru_cache(maxsize=100000)
def entropy_rat(t,R):
    """Entropy of Bernoulli(t/R) in nats, enclosing scaled by 2**128."""
    if t==0 or t==R:return 0,0
    l1,u1=log_rat(t,R)
    l2,u2=log_rat(R-t,R)
    # h=-p log p -(1-p)log(1-p)
    lo=-(ceildiv(t*u1,R)+ceildiv((R-t)*u2,R))
    hi=-((t*l1)//R + ((R-t)*l2)//R)
    assert 0<=lo<=hi
    return lo,hi

@lru_cache(maxsize=32)
def alpha_mult(m):
    """b=log_2(16/m), as fixed point bracket"""
    l,h=log_rat(16,m)
    return (l*S//LOG2H,ceildiv(h*S,LOG2L))

@lru_cache(maxsize=100000)
def baseline_lower(m,t,R):
    hlow,hhi=entropy_rat(t,R)
    psi_lo=LOG2L-hhi
    if psi_lo<0:psi_lo=0
    return alpha_mult(m)[0]*psi_lo//S

@lru_cache(maxsize=100000)
def weights(t,R):
    return tuple(t**k*(R-t)**(4-k) for k in range(5))

def D_upper(rows,m,t,R):
    w=weights(t,R)
    denom=m*R**4
    total=0
    for row in rows:
        a=sum(z*v for z,v in zip(row,w))
        if not a:continue
        _,up=log_rat(16*a,denom)
        total+=ceildiv(a*up,denom)
    return total

def certified_gap(m,rows,tl,Rl,tr,Rr):
    # interval [tl/Rl,tr/Rr]. D(left) >= D(p), baseline(right) <= baseline(p)
    assert tl*Rr<=tr*Rl
    return baseline_lower(m,tr,Rr)-D_upper(rows,m,tl,Rl)

def exact_p_quarter(reps):
    t=time.monotonic()
    count=0; smallest=10**100
    for r in reps:
        if subcube(r):continue
        d=certified_gap(r.bit_count(),dist_counts(r),1,4,1,4)
        if d<=0:raise AssertionError(('p1/4 FAIL',r,d))
        count+=1;smallest=min(smallest,d)
    print('EXACT_P_1_4_PASS',count,'min_gap_lower',smallest/S,'elapsed',round(time.monotonic()-t,2),flush=True)
    return count,smallest

def endpoint_bounds(reps,low_R=1<<40,high_rho_R=1024):
    # Low-noise: H'(p) >= (B/m)(1-5mp)*(log1/p - log(m)-8p) from boundary edges.
    # To prove F'>0 on (0, 1/low_R], suffice:
    # ((B/m)*(1-5m/R)-b)*log(R) - (B/m)*(log(m)+8/R)>0
    # Every comparison in fixed point rigorous directed bounds.
    t0=time.monotonic()
    low_count=0; high_count=0
    rho=1/high_rho_R
    for r in reps:
        if subcube(r):continue
        m=r.bit_count();B=boundary(r)
        b_hi=alpha_mult(m)[1]
        lm_hi=log_rat(m)[1]
        logR_lo=log_rat(low_R)[0]
        c_num=B*(low_R-5*m)
        c_den=m*low_R
        # scaled lower of c - b
        a_lo=c_num*S//c_den-b_hi
        if a_lo<=0:raise AssertionError(('low a',r,a_lo))
        # (a-b)*ln R - (B/m)*(ln m+8/R) >0
        lhs=(a_lo*logR_lo)//S
        rhs=ceildiv(B*(lm_hi*low_R+8*S),m*low_R)
        if lhs<=rhs:raise AssertionError(('low fail',r,(lhs-rhs)/S))
        low_count+=1
        # High-noise: delta upper = (1+rho)^4-1, total Fourier chi2.
        # D <= rho^2/2 * (L1+rho^2*(sum higher c_S^2)) / (1-delta).
        # benchmark >= b*rho^2/2.
        # Compare rational Fourier coefficient values against b lower bound.
        coeff=[]
        for subset in range(1,16):
            num=sum((-1)**((x&subset).bit_count()&1) for x in range(16) if r>>x&1)
            coeff.append((subset.bit_count(),num*num))
        l1=sum(v for k,v in coeff if k==1)
        higher=sum(v for k,v in coeff if k>=2)
        # rational (L1+rho^2*higher)/(m^2*(1-delta)) < b
        # delta = ((R+1)^4-R^4)/R^4
        RR=high_rho_R
        denom= (2*RR**4-(RR+1)**4) * m*m
        assert denom>0
        numer=l1*RR**4+higher*RR**2
        b_lo=alpha_mult(m)[0]
        if numer*S >= b_lo*denom:raise AssertionError(('high fail',r,numer/denom,b_lo/S))
        high_count+=1
    print('ANALYTIC_ENDPOINTS_PASS',low_count,high_count,'elapsed',round(time.monotonic()-t0,2),flush=True)

def central(reps,logpath):
    # 2^-40 <= p <= 0.5-1/2048, where rho<=1/1024 high bound applies
    p_lo_num,p_lo_den=1,1<<40
    p_hi_num,p_hi_den=1023,2048
    counts=[]; records=[]; min_slack=None;t0=time.monotonic()
    dirname=os.path.dirname(os.path.abspath(logpath))
    evidence_path=os.path.join(dirname,'central_intervals.tsv')
    ev=open(evidence_path,'w',encoding='ascii')
    ev.write('mask\tleft_num\tleft_den\tright_num\tright_den\tcertified_gap_lower_2p128\n')
    for idx,r in enumerate(reps):
        if subcube(r):continue
        m=r.bit_count();rows=dist_counts(r)
        # Adaptive dyadic subdivision. Endpoint rationals represented by pairs (n,d).
        todo=[(p_lo_num,p_lo_den,p_hi_num,p_hi_den)]
        cnt=0
        while todo:
            nl,dl,nr,dr=todo.pop()
            v=certified_gap(m,rows,nl,dl,nr,dr)
            if v>0:
                cnt+=1
                ev.write(f'{r}\t{nl}\t{dl}\t{nr}\t{dr}\t{v}\n')
                if min_slack is None or v<min_slack:min_slack=v
                continue
            # subdivide using exact midpoint
            midn=nl*dr+nr*dl; midd=2*dl*dr
            g=math.gcd(midn,midd);midn//=g;midd//=g
            assert nl*midd<midn*dl and midn*dr<nr*midd,(r,nl,dl,nr,dr)
            todo.append((midn,midd,nr,dr));todo.append((nl,dl,midn,midd))
            if len(todo)>1000:raise RuntimeError(('too much',r,cnt))
        counts.append(cnt)
        records.append({'representative':r,'orbit_index':idx,'interval_count':cnt})
        if len(counts)%50==0:
            print('CENTRAL_PROGRESS',len(counts),'/396','total',sum(counts),'elapsed',round(time.monotonic()-t0,1),flush=True)
    ev.close()
    report={'interval_total':sum(counts),'min_intervals':min(counts),'max_intervals':max(counts),'min_slack_lower_nats':str(min_slack/S),'records':records}
    with open(logpath,'w') as f:json.dump(report,f,indent=2)
    print('CENTRAL_CERTIFIED_PASS',len(counts),sum(counts),'min_slack',min_slack/S,'elapsed',round(time.monotonic()-t0,1),flush=True)

if __name__=='__main__':
    import sys
    reps,sizes=classes()
    mode=sys.argv[1] if len(sys.argv)>1 else 'quarter'
    if mode=='quarter':exact_p_quarter(reps)
    if mode=='endpoints':endpoint_bounds(reps)
    if mode=='central':central(reps,os.path.join(os.path.dirname(os.path.abspath(__file__)),'central_certificate.json'))
