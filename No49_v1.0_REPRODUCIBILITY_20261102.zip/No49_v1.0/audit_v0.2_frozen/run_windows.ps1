$ErrorActionPreference = 'Stop'
Set-Location -LiteralPath $PSScriptRoot
Get-Content -LiteralPath './SHA256SUMS.txt' | ForEach-Object {
    if (-not [string]::IsNullOrWhiteSpace($_)) {
        $items = $_ -split '  ', 2
        if ($items.Count -ne 2) { throw "Bad hash manifest line: $_" }
        $file = Join-Path $PSScriptRoot $items[1]
        if (-not (Test-Path -LiteralPath $file -PathType Leaf)) { throw "Missing: $file" }
        $actual = (Get-FileHash -LiteralPath $file -Algorithm SHA256).Hash.ToLowerInvariant()
        if ($actual -ne $items[0]) { throw "SHA256 mismatch: $file" }
    }
}
Write-Host 'SHA256 PASS'
& python -B './verify_no49.py'
if ($LASTEXITCODE -ne 0) { throw "No49 independent replay failed: $LASTEXITCODE" }
Write-Host 'No49 internal certificate PASS; novelty / external audit HOLD'
