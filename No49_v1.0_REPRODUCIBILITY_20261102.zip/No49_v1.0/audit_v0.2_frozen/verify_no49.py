#!/usr/bin/env python3
"""Replay and check No49 finite certificate. Python 3.10+, standard library only.
Fails closed on missing or malformed certificate, failed inequalities, wrong hashes.
"""
import os,csv,json,hashlib,sys
from collections import defaultdict
from check_no49 import classes,subcube,dist_counts,face_partitions
from cert_no49 import certified_gap,endpoint_bounds,exact_p_quarter,S
HERE=os.path.dirname(os.path.abspath(__file__))

def verify():
    reps,sizes=classes()
    assert len(reps)==401 and sum(sizes)==65535
    noncube=[r for r in reps if not subcube(r)]
    assert len(noncube)==396
    assert face_partitions()==30
    exact_p_quarter(reps)
    endpoint_bounds(reps)
    summary=json.load(open(os.path.join(HERE,'central_certificate.json'),encoding='utf-8'))
    file_path=os.path.join(HERE,'central_intervals.tsv')
    count=0; min_v=None; per=[]; last=None
    with open(file_path,encoding='ascii',newline='') as fh:
        rdr=csv.DictReader(fh,delimiter='\t')
        assert rdr.fieldnames == ['mask','left_num','left_den','right_num','right_den','certified_gap_lower_2p128']
        for rec in rdr:
            r,nl,dl,nr,dr,v=(int(rec[k]) for k in rdr.fieldnames)
            assert nl>0 and dl>0 and nr>0 and dr>0
            assert nl*dr<nr*dl
            if last is None or r!=last['mask']:
                if last is not None:
                    assert last['right_num']*2048==1023*last['right_den'], 'previous representative misses upper endpoint'
                assert len(per)<len(noncube) and r==noncube[len(per)]
                assert nl*(1<<40)==dl, 'missing lower endpoint'
                per.append(0)
            else:
                assert last['right_num']*dl==nl*last['right_den'], 'interval hole or overlap'
            expected=certified_gap(r.bit_count(),dist_counts(r),nl,dl,nr,dr)
            assert expected==v and v>0, ('bad bound',r,count)
            per[-1]+=1
            min_v=v if min_v is None else min(min_v,v)
            count+=1
            last={'mask':r,'right_num':nr,'right_den':dr}
    assert last and last['right_num']*2048==1023*last['right_den']
    assert len(per)==396
    assert count==31704==summary['interval_total']
    assert min(per)==summary['min_intervals'] and max(per)==summary['max_intervals']
    assert len(summary['records'])==396
    assert all(x['representative']==r and x['interval_count']==n for x,r,n in zip(summary['records'],noncube,per))
    assert min_v is not None and str(min_v/S)==summary['min_slack_lower_nats']
    print('FULL_CERTIFICATE_REPLAY PASS; subsets=65535; orbits=401; noncube_orbits=396; intervals=31704; min_bound=',min_v/S)

if __name__=='__main__':
    try:verify()
    except Exception as exc:
        print('FAIL',repr(exc),file=sys.stderr)
        sys.exit(1)
