#!/usr/bin/env python3
"""Independent, reproducible enumeration for No.49 (no external packages).
This is a numerical / combinatorial verifier, NOT a certificate for continuum p.
"""
import math, itertools, argparse, json, hashlib
N=16
FULL=(1<<N)-1

def symmetry_maps():
    flips=[]
    for i in range(4):
        flips.append(tuple(v^(1<<i) for v in range(N)))
    swaps=[]
    for i in range(3):
        def sw(v,i=i):
            if ((v>>i)&1)==((v>>(i+1))&1):return v
            return v^((1<<i)|(1<<(i+1)))
        swaps.append(tuple(sw(v) for v in range(N)))
    return flips+swaps

MAPS=symmetry_maps()
def mapped(mask, mp):
    out=0
    while mask:
        bit=mask&-mask
        out|=1<<mp[bit.bit_length()-1]
        mask^=bit
    return out

def classes():
    used=bytearray(1<<N)
    reps=[]
    class_sizes=[]
    for k in range(1,1<<N):
        if used[k]: continue
        seen={k}; todo=[k]; used[k]=1
        while todo:
            a=todo.pop()
            for mp in MAPS:
                b=mapped(a,mp)
                if b not in seen:
                    seen.add(b);todo.append(b);used[b]=1
        reps.append(k);class_sizes.append(len(seen))
    return reps,class_sizes

def subcube(mask):
    s=[i for i in range(N) if mask>>i&1]
    m=len(s)
    if m&(m-1):return False
    fixed=[j for j in range(4) if all((x>>j&1)==(s[0]>>j&1) for x in s)]
    return len(fixed)==4-int(math.log2(m))

def boundary(mask):
    return sum(1 for x in range(N) if mask>>x&1 for j in range(4) if not ((mask>>(x^(1<<j)))&1))

def dist_counts(mask):
    xs=[x for x in range(N) if mask>>x&1]
    return [[sum((x^y).bit_count()==k for x in xs) for k in range(5)] for y in range(N)]

def gap(mask,p,rows=None):
    if rows is None:rows=dist_counts(mask)
    m=mask.bit_count()
    weights=[p**k*(1-p)**(4-k) for k in range(5)]
    q=[sum(a*w for a,w in zip(row,weights))/m for row in rows]
    ent=-sum(t*math.log(t) for t in q if t>0)
    hb= -p*math.log(p)-(1-p)*math.log1p(-p) if p>0 and p<1 else 0.
    return ent-math.log(m)-math.log2(16/m)*hb

def face_partitions():
    faces=[mask for mask in range(1,1<<16) if mask.bit_count()==4 and subcube(mask)]
    assert len(faces)==24
    ct=0
    for fs in itertools.combinations(faces,4):
        if (fs[0]|fs[1]|fs[2]|fs[3])==FULL and sum(x.bit_count() for x in fs)==16:
            ct+=1
    return ct

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--json',default='');args=ap.parse_args()
    reps,sizes=classes();assert sum(sizes)==65535
    assert len(reps)==401, len(reps)
    cidx=[i for i,r in enumerate(reps) if subcube(r)]
    assert len(cidx)==5 and sum(sizes[i] for i in cidx)==81
    assert face_partitions()==30
    noncube=[r for r in reps if not subcube(r)]
    print('SUBSETS 65535, ORBITS',len(reps),'SUBCUBE_ORBITS',len(cidx),'SUBCUBES',sum(sizes[i] for i in cidx),'NONCUBE_ORBITS',len(noncube),'FACE_PARTITIONS 30, LABELED 720')
    allresults=[]
    for p in (.01,.1,.25,.4,.49):
        vals=[(gap(r,p),r) for r in noncube]
        minval,argmin=min(vals)
        print(f'p={p:.4f} min_gap_nats={minval:.15g} mask={argmin} size={argmin.bit_count()} violations={sum(v < -1e-12 for v,r in vals)}')
        allresults.append({'p':p,'min_gap_nats':minval,'argmin_mask':argmin})
    # Exact discrete edge and spectral margins for analytic endpoint candidates
    e_min=(float('inf'),None)
    s_min=(float('inf'),None)
    for r in noncube:
        m=r.bit_count();b=math.log2(16/m)
        e=boundary(r)/m-b
        c=[sum(((-1)**((x>>j)&1)) for x in range(16) if r>>x&1)/m for j in range(4)]
        s=b-sum(v*v for v in c)
        if e<e_min[0]:e_min=(e,r)
        if s<s_min[0]:s_min=(s,r)
    print('min_positive_edge_margin',e_min,'min_positive_spectral_margin',s_min)
    info={'class_count':len(reps),'size_sum':sum(sizes),'subcube_count':81,'face_partitions':30,'numerical':allresults,'min_edge_margin':e_min,'min_spectral_margin':s_min}
    if args.json:
        with open(args.json,'w') as f:json.dump(info,f,indent=2)
if __name__=='__main__':main()
