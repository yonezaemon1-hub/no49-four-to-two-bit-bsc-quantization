# No.49 — computer-assisted proof audit notes v0.2 (2026-11-02)

**Status: MATHEMATICAL CERTIFICATE / INTERNAL PASS; PRIORITY, NOVELTY AND EXTERNAL INDEPENDENT AUDIT: INCONCLUSIVE. RELEASE HOLD.**

## Statement

Let X be uniform on `{0,1}^4`, let Y = X xor Z with independent Bernoulli(p) noise bits, `0 <= p <= 1/2`, and let Q map `{0,1}^4` to at most four output symbols. Then:

`I(Q(X);Y) <= 2*(1-h_2(p))` bits.

For `0<p<1/2`, equality holds precisely when the nonempty fibers of Q partition the 16-point cube into four 2-dimensional subcubes (i.e. four faces), each mapped to a different output symbol. There are 30 unlabeled partitions, or 720 maps to four labeled output symbols.

**Endpoints (not the open-interval equality characterization).** At `p=0`, `Y=X` and `I(Q(X);Y)=H(Q(X))`; equality with the 2-bit upper bound holds for **every** map having four equiprobable outputs (four fibers of size 4), not just face partitions. At `p=1/2`, `Y` is independent of `X`, both sides of the information inequality are zero, and **every** map `Q` attains equality. Thus the **upper bound is valid on the closed interval**, whereas the **30-partition uniqueness characterization holds only for `0<p<1/2`**.

## Stronger subset lemma used

Let A be any nonempty subset of the 4-cube, `m=|A|`, `P_A` uniform on A, and `q_p` the output of the 4-fold BSC applied to `P_A`. With `U_4` the uniform distribution, define `psi(p)=ln 2 - h(p)` (all logarithms and entropies in nats) and `b_m=log_2(16/m)`. Then

`D(q_p || U_4) <= b_m * psi(p)`.

Equality for any `0<p<1/2` occurs only if A is a subcube. Subcubes attain equality identically. The verifier checks every non-subcube orbit strictly, with three exhaustive ranges.

### Reduction to the information theorem

The random output C=Q(X) has fibers A_c. The chain-rule identity is

`I(C;Y) = sum_c (|A_c|/16) D(q_{p,A_c} || U_4)`.

The subset lemma therefore implies

`I(C;Y) <= psi(p) * sum_c (|A_c|/16)*log_2(16/|A_c|) = psi(p)*H_2(C) <= 2 psi(p)` (nats).

The final equality `H_2(C)=2` forces all four cell sizes to be 4; strictness of subset lemma forces each to be a face. The 30-partition count is exhaustive, separately replayed by the verifier.

### Symmetry orbits

The 4 hypercube bit flips and three adjacent coordinate swaps generate the whole automorphism group `(Z_2)^4 ⋊ S_4`. Its action on the 65,535 nonempty sets yields exactly 401 orbits, 5 of which are the subcubes. The strict inequality needs only the other 396 representatives. The certificates use integer masks for reproducibility.

### Central range: `[2^-40, 1023/2048]`

Let `D_A(p) = D(q_{p,A} || U_4)`, `B_m(p) = b_m * psi(p)`. Both are non-increasing for `0<=p<=1/2`: the first by the data-processing inequality for composed BSCs and the second by monotonicity of binary entropy. For each recorded rational interval `[l,r]`, it is therefore enough to certify

`B_m(r) - D_A(l) > 0`.

31,704 closed rational intervals (across 396 non-subcube representatives) cover the central range without holes. Every comparison is *integer arithmetic* with outward rounding. The CSV/TSV cert includes the endpoints and a conservative gap lower bound at scale `2^128`.

**Logarithm enclosures and rounding budget.** Normalize every positive rational as `x=2^e t`, `1<=t<2`, with integer `e`. Then `ln x = e ln 2 + 2 sum_{k>=0} z^(2k+1)/(2k+1)`, `z=(t-1)/(t+1)` and `0<=z<1/3`. Use 60 terms and outward integer rounding at scale `2^128`. The omitted positive tail, after multiplying by `2^128`, is below one integer unit, because `9*2^128 < 4*(121)*3^121`. This is checked as an assertion. Treat signed exponent contributions with reversed bounds where required. The code encloses every entropy and divergence by integer-only operations. Precisely, `S=2^128`; each logged quantity is bracketed by integers at scale `S` with outward rounding, and the truncated log-series tail contributes less than one additional integer unit at this scale, already included in the upper bracket. One unit is `2^-128 ≈ 2.938735877e-39` nat. The recomputed smallest **certified lower bound**, after all outward-rounding operations (not before), is `1.772151923623782e-14` nat over the 31,704 central intervals; every recorded scaled integer lower bound is positive. This margin is not an estimate of the total rounding error: validity follows from outward interval containment in each computation.

### Low-noise range: `(0, 2^-40]`

Write `B` for the number of edges of the 4-cube with one endpoint inside A and one outside. With `q=q_p`, entropy production along the BSC semigroup gives exactly

`dH(q)/dp = (1/(1-2p)) sum_{edges {x,y}} (q_x-q_y)*(ln q_x-ln q_y)`.

For an edge with x in A and y outside: `q_x >= (1-p)^4/m >= (1-4p)/m` and `q_y <= p` (all input members are at distance >=1). For `0<p<=2^-40`, the corresponding term is at least

`(1-5 m p)/m * (ln(1/p)-ln m-8p)`, where we use `ln(1-4p)>=-8p`, `1/(1-2p)>=1`, and the positivity of each factor.

Let `F(p) = B_m(p)-D_A(p) = H(q_p) -ln m -b_m h(p)`; `F(0)=0`. Thus

`F'(p) >= [B/m*(1-5m p)-b_m] ln(1/p) - B/m*(ln m+8p)`.

For clarity, these two elementary inequalities are used when simplifying the derivative bound:

1. `h'(p) = ln((1-p)/p) <= ln(1/p)` for `0 < p <= 2^-40`, since `ln(1-p) <= 0`.
2. `0 < (1-5m p) <= 1` for `1 <= m <= 16` and `0 < p <= 2^-40`; hence `(1-5m p)*(ln m+8p) <= ln m+8p`, because the final factor is nonnegative.

Together they justify the displayed conservative lower bound on `F'(p)` with no implicit sign reversal.

The finite check in `endpoint_bounds` proves, with directed integer log bounds, that this expression is positive for every non-subcube representative uniformly on `(0,2^-40]`. So `F>0` on that interval.

### High-noise range: `[1023/2048, 1/2)`

Let `rho=1-2p`, so `0<rho<=1/1024`. Fourier-expand the normalized output density relative to uniform measure as `16*q_p(y)=1+v(y)`. For each nonempty character S, its coefficient is `rho^|S| c_S`, where `c_S=(1/m) sum_{x in A} (-1)^(sum_{i in S} x_i)`.

Set `L1=sum_{|S|=1} c_S^2` and `Lhi=sum_{|S|>=2} c_S^2`. As `|v|<=delta=(1+rho)^4-1<1`, Taylor's theorem for `(1+v)ln(1+v)-v` gives

`D_A(p) <= [rho^2 /(2*(1-delta))] * (L1+rho^2 Lhi)`.

The entropy function satisfies `psi(p)>=rho^2/2`. Consequently `F(p)>0` follows from the finite rational/rigorously enclosed comparison

`(L1 + Lhi/1024^2) / (1-[(1+1/1024)^4-1]) < b_m`.

All 396 non-subcube orbits pass via rational Fourier coefficients and rigorous log_2 bounds.

At `p=0`, every set satisfies equality, and at `p=1/2` every set yields zero. The strict equality characterization above is deliberately restricted to the open range.

## Replay

From this directory, Python 3.10+ / standard library only:

`python -B verify_no49.py`

This replay reconstructs the symmetry classes and the 30 face partitions, checks the 25% bound and both endpoint analytic arguments, validates the exact coverage of all 31,704 rational intervals, and recomputes each certified lower bound from scratch. `cert_no49.py central` regenerates the interval file. `check_no49.py` independently computes numerical checkpoints (NOT a proof).

## Limitations / novelty

This is a **computer-assisted proof**, not a human peer review or proof in Lean/Coq. A separate AI audit has been reported as an independent reproduction, but its independently written code and signed execution record are not included in this archive. Although the finite checking is exact, the derivations written above also need adversarial review. This internal source/replay cannot establish academic novelty. Moazzeni (2026), *The Fixed-k Quantization Problem for Noisy Binary Sources*, DOI `10.1109/TIT.2026.3741662`, has relevant high-noise and subcube results. The publisher full text / all theorem statements have not been independently checked against this statement. The 4-to-2 all-noise claim must remain **NOVELTY INCONCLUSIVE** and **RELEASE HOLD** until primary-source comparison and external audit.

## v0.2 editorial change record

Clarified endpoint equality cases, made the two low-noise derivative inequalities explicit, and documented the `2^128` rounding scale and the certified positive margin. Mathematical statement, certificate generator/verifier and fixed certificate evidence are unchanged from v0.1. RELEASE HOLD; NOVELTY INCONCLUSIVE.
