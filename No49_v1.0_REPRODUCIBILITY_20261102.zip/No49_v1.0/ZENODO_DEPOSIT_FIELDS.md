# Zenodo deposit draft — No.49 v1.0

- Resource type: Publication > Preprint
- Title: Optimal Four-to-Two-Bit Quantization Through a Binary Symmetric Channel: A Finite Computer-Assisted Proof with an Equality Classification
- Creator: Yonezu, Ryutaro
- Affiliation: Independent Researcher
- Publication date: 2026-11-02
- Version: v1.0
- Rights: All rights reserved (do not select a Creative Commons or MIT license)
- Keywords: information theory; binary symmetric channel; multibit quantization; computer-assisted proof; Boolean hypercube; entropy
- Description: A finite computer-assisted proof of the 4-to-2-bit quantization bound for every binary-symmetric-channel noise level, with a classification of equality cases. Reproducible integer arithmetic certificate and audit package. Novelty INCONCLUSIVE: full theorem-level comparison with T. Moazzeni (IEEE TIT 2026) is incomplete. Not human peer-reviewed.
- Files: `No49_v1.0_PREPRINT_20261102.pdf` and `No49_v1.0_REPRODUCIBILITY_20261102.zip`
- Related literature: Mahdavifar and Beirami, arXiv:2609.26444; Huleihel and Ordentlich, DOI 10.1109/ISIT.2017.8006496; Moazzeni, DOI 10.1109/TIT.2026.3741662.
- DOI: Leave unassigned until Zenodo confirms publication.
