# No.49 - Optimal Four-to-Two-Bit Quantization Through a Binary Symmetric Channel

**Ryutaro Yonezu — Independent Researcher**  
Version 1.0, 2026-11-02  
License: **All rights reserved**  
Review: **Not human peer-reviewed**  
Proof: **Computer-assisted; finite certificate replayable with Python 3.10+ standard library**  
Novelty: **INCONCLUSIVE** (full comparison with T. Moazzeni, IEEE TIT 2026, not completed)

The associated release PDF is `No49_v1.0_PREPRINT_20261102.pdf`. This ZIP contains the paper's LaTeX source and the **historically frozen** v0.2 audit package. No mathematics, code, or certificate data from v0.2 has been changed for v1.0. The historical audit files still say "RELEASE HOLD" because they accurately describe the status **on the date v0.2 was frozen**; the author's release approval came afterward and is not a retroactive edit to that evidence.

## Result

For `X` uniform on `{0,1}^4`, `Y = X xor Z` with independent Bernoulli(p) noise, and any quantizer `Q:{0,1}^4 -> {0,1}^2`,

`I(Q(X);Y) <= 2 (1 - h_2(p))` bits, for `0 <= p <= 1/2`.

For `0 < p < 1/2`, the equality partitions are exactly the 30 partitions of the cube into four 2-dimensional faces (720 mappings when outputs are labeled). At p=0 and p=1/2 the equality cases are more numerous; see the paper.

## Verify

1. Unzip this package.
2. Check `SHA256SUMS_RELEASE.txt` using a SHA-256 tool.
3. Change directory to `audit_v0.2_frozen/`.
4. Run `python -B verify_no49.py`.
5. On Windows, one-shot SHA-256 and certificate check: `powershell -NoProfile -ExecutionPolicy Bypass -File .\run_windows.ps1` from the same directory.

Expected key output:

`FULL_CERTIFICATE_REPLAY PASS; subsets=65535; orbits=401; noncube_orbits=396; intervals=31704; min_bound= 1.772151923623782e-14`

The original v0.2 source ZIP SHA-256 is `283b3079e6ee8e4bbca1d4634c01a5aee77ae1f88fb922cd35a388f20dbead41`.

## Scope and provenance

- Limited to n=4, k=2, not a proof of the general 2-7-bit conjecture.
- AI-assisted manuscript and proof development; an independent AI replay is reported by the author but no third-party code or signed execution record is bundled.
- No human peer review and no formal proof assistant certification.
- IEEE source text for Moazzeni (2026) was not available for full theorem-level comparison. Priority is not claimed.
- This package is a prepared release artifact; **its presence does not itself prove that GitHub or Zenodo publication has occurred**.
